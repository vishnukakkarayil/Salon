import React from 'react';
import Login from './Login';
import Register from './Register';
import Error from '../Error/Error';
import {Route, Switch} from 'react-router-dom';
const Loginboard = () => {
    return(<>
    <div className="login-board-wrap">
        <Switch>
            <Route exact path="/" component={Login} />
            <Route exact path="/register" component={Register} />
            <Route component={Error} />
        </Switch>
    </div>   
        
        </>
    )
}

export default Loginboard