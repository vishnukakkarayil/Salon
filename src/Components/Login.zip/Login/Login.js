import React, {useState} from 'react';
import {Link} from 'react-router-dom';
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBBtn } from 'mdbreact';
const Login = () => {
    return(
        <div className="log-register">
            <div className="lr-left-wrap">
                <div className="reg-desc">
                    <Link to="/">
                        {/* <img src="../../../src/A" */}
                        <img className="salon-logo" src="../../../src/Assets/logo.jpg" />
                    </Link>
                    <p>It is a long established fact that a reader will be distracted by 
                        the readable content of a page when looking at its layout. The point                     
                        of using Lorem Ipsum is that it has a more-or-less normal distribution
                        of letters, as opposed .
                    </p>
                </div>   
            </div>
            <div className="lr-right-wrap">
                <div className="salon-login">                    
                        <MDBContainer>
                            <MDBRow>
                                <MDBCol>
                                    <p className="h4 text-center mb-4">Sign in</p>
                                    <p className="text-center">Create my account <Link to="/register">Register</Link></p>
                                    <form>                                        
                                        <div className="grey-text">
                                            <MDBInput className="mb-4" label="Email" icon="envelope" group type="email" validate error="wrong"
                                                success="right" />
                                            <MDBInput label="Password" icon="lock" group type="password" validate />
                                        </div>
                                        <div className="text-center">
                                            <MDBBtn rounded gradient="blue">Sign In</MDBBtn>
                                        </div>
                                    </form>
                                    <Link>
                                        <p className="mt-3 text-center">Forget password</p>
                                    </Link>
                                </MDBCol>
                            </MDBRow>
                        </MDBContainer>                  
                </div>                
            </div>
            
        </div>
    )
}

export default Login;